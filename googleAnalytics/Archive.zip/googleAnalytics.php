<?php
defined('_JEXEC') or die();
 
jimport('joomla.event.plugin');

class plgSystemGoogleAnalytics extends JPlugin
{
	var $DOM = NULL;
	
	function onBeforeRender(){
		
		$dom = $this->getDOM();
		$body = $dom->getElementsByTagName('body')->item(0);
		
		
		$scriptTag = $dom->createElement('script','hi');	
		$fbroot->setAttribute('type','text/javascript');
		$body->appendChild($fbroot);
		
		$this->setBody($scriptTag);
		
	}
	
	public function getDOM(){
		if(is_null($this->DOM)){
			$html = JResponse::getBody();
			$this->DOM = new DOMDocument();
			$this->DOM->formatOutput = true;
			$this->DOM->loadHTML($html);
		}
		return $this->DOM;
	}
	
	public function setBody(){
		$dom = $this->getDOM();
		JResponse::setBody($dom->saveHTML());
	}

}
?>