<?php 
/*------------------------------------------------------------------------
# author    your name or company
# copyright Copyright (C) 2011 example.com. All rights reserved.
# @license  http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Website   http://www.example.com
-------------------------------------------------------------------------*/

defined( '_JEXEC' ) or die; 

// variables
$tpath = $this->baseurl.'/templates/'.$this->template;
$this->setGenerator(null);

?><!doctype html>
<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="<?=$this->language?>"> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="<?=$this->language?>"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="<?=$this->language?>"> <![endif]-->
<!--[if gt IE 8]><!-->  <html class="no-js" lang="<?=$this->language?>"> <!--<![endif]-->

	<head>
		<jdoc:include type="head" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- mobile viewport optimized -->
		<link rel="apple-touch-icon-precomposed" href="<?=$tpath?>/apple-touch-icon-57x57.png"> <!-- iphone, ipod, android -->
		<link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?=$tpath?>/apple-touch-icon-72x72.png"> <!-- ipad -->
		<link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?=$tpath?>/apple-touch-icon-114x114.png"> <!-- iphone retina -->
		<link href="<?=$tpath?>/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" /> <!-- favicon -->
		<link rel="stylesheet" href="<?=$tpath?>/css/print.css?v=1.0.0" type="text/css" /> <!-- stylesheet -->
		<script src="<?=$tpath?>js/modernizr.js"></script> <!-- put all javascripts at the bottom, accept of modernizr.js -->
	</head>
	
	<body id="print">
		<div id="overall">
			<jdoc:include type="message" />
			<jdoc:include type="component" />
		</div>
	</body>

</html>
